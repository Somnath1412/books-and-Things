<?php


$link = mysqli_connect("localhost","root","","bookstore");

if(!$link){

	echo "Error occured. Unable to connect to database. Try to refresh page";
}

 ?>
