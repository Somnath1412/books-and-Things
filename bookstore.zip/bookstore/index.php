<?php

header('location: user/index.php');

?>