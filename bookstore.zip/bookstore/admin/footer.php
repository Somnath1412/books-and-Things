<!-- Footer -->

<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<footer class="py-5 bg-dark">
    <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; www.nomadic.com 2018</p>
        <p class="m-0 text-center text-white">This site is developed and hosted by Awwesomee Web Developers</p>
    </div>
    <!-- /.container -->
</footer>

<script type="text/javascript">
	$(document).ready(function(){


	});
</script>
</body>
</html>
